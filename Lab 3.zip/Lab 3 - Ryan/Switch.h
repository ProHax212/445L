#include <stdint.h>
#include "PLL.h"
#include "../inc/tm4c123gh6pm.h"

uint8_t Pause(void);
void PortF_Init(void);
